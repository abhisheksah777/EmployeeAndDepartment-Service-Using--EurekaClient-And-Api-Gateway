package com.example.Department.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Department.DTO.DepartmentDTO;
import com.example.Department.ServiceImpl.DepartmentServiceImpl;


@RestController
@RequestMapping("/department")

public class DepartmentController {
	@Autowired
	private DepartmentServiceImpl departmentServiceImpl;

	@PostMapping("/save")
	public ResponseEntity<DepartmentDTO> postMethodName(@RequestBody DepartmentDTO departmentdto) {
		DepartmentDTO saveDepartmentDto=departmentServiceImpl.saveDepartment(departmentdto);
		
		return new ResponseEntity<>(saveDepartmentDto,HttpStatus.CREATED);
	}
    @GetMapping("/{id}")
    public ResponseEntity<DepartmentDTO> getMethodName(@PathVariable("id")Long eid ) {
    	DepartmentDTO saveDepartmentDto=departmentServiceImpl.getDepartmentById(eid);
		 return new ResponseEntity<>(saveDepartmentDto,HttpStatus.CREATED);
        
    }
    
}
