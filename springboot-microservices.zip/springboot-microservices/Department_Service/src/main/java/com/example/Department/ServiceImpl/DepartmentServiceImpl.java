package com.example.Department.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Department.DTO.DepartmentDTO;
import com.example.Department.Entity.Department;
import com.example.Department.Repository.DepartmenRepo;
import com.example.Department.ResourceConversion.ResourceConvert;
import com.example.Department.Service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired
	private DepartmenRepo departmenRepo;
	ResourceConvert resourceConvert;

	@Override
	public DepartmentDTO saveDepartment(DepartmentDTO departmentDTO) {
		Department saveDepartmentDto = departmenRepo.save(resourceConvert.DtoToDepartment(departmentDTO));
		return resourceConvert.departMentTodeptDto(saveDepartmentDto);
	}

	@Override
	public DepartmentDTO getDepartmentById(Long departmentId) {
		Department saveDepartmentDto = departmenRepo.findById(departmentId).get();
		return resourceConvert.departMentTodeptDto(saveDepartmentDto);
	}

}
