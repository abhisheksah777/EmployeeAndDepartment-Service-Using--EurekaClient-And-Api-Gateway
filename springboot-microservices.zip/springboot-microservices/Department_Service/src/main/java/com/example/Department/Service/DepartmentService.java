package com.example.Department.Service;

import com.example.Department.DTO.DepartmentDTO;

public interface DepartmentService {
	
	public DepartmentDTO saveDepartment(DepartmentDTO departmentDTO);
	public DepartmentDTO getDepartmentById(Long departmentId);

}
