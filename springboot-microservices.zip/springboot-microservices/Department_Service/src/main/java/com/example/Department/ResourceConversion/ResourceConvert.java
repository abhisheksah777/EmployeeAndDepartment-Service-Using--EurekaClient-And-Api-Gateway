package com.example.Department.ResourceConversion;

import com.example.Department.DTO.DepartmentDTO;
import com.example.Department.Entity.Department;

public class ResourceConvert {

	public static DepartmentDTO departMentTodeptDto(Department department) {
		DepartmentDTO savDepartmentDTO = new DepartmentDTO(department.getDept_Id(), department.getDepartmentName(),
				department.getDepartmentDesc(), department.getDepartmentCode());
		return savDepartmentDTO;

	}

	public static Department DtoToDepartment(DepartmentDTO departmentDto) {
		Department savDepartmentDept = new Department(departmentDto.getDept_Id(), departmentDto.getDepartmentName(),
				departmentDto.getDepartmentDesc(), departmentDto.getDepartmentCode());
		return savDepartmentDept;

	}
}
