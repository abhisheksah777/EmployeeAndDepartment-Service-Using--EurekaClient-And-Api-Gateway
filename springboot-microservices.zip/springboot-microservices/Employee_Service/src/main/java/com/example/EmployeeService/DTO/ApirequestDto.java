package com.example.EmployeeService.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApirequestDto {
	private EmpolyeeDto empolyeeDto;
	private DepartmentDto departmentDto;
}
