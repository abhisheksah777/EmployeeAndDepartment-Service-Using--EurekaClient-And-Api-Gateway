package com.example.EmployeeService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.EmployeeService.DTO.ApirequestDto;
import com.example.EmployeeService.DTO.DepartmentDto;
import com.example.EmployeeService.DTO.EmpolyeeDto;
import com.example.EmployeeService.FeignCilent.ApiCilent;
import com.example.EmployeeService.ServiceImpl.EmployeeServiceImpl;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;
//	@Autowired
//	private RestTemplate restTemplate;
//	@Autowired
//	private WebClient webClient;
	@Autowired
	private ApiCilent apiCilent;

	@PostMapping("/save")
	public ResponseEntity<EmpolyeeDto> saveEmployee(@RequestBody EmpolyeeDto empolyeeDto) {
		EmpolyeeDto saveEmployee = employeeServiceImpl.saveEmployee(empolyeeDto);
		return new ResponseEntity<>(saveEmployee, HttpStatus.CREATED);

	}

	@GetMapping("/{id}")
	public ResponseEntity<ApirequestDto> getEmployee(@PathVariable("id") Long empId) {

		EmpolyeeDto saveEmployee = employeeServiceImpl.getEmployeeById(empId);
//		ResponseEntity<DepartmentDto> responseEntity = restTemplate.getForEntity(
//				"http://localhost:8081/department/" + saveEmployee.getDepartmentid(), DepartmentDto.class);
//		DepartmentDto departmentDto = responseEntity.getBody();
//		DepartmentDto departmentDto = webClient.get().uri("http://localhost:8081/department/" + saveEmployee.getDepartmentid())
//				.retrieve().bodyToMono(DepartmentDto.class).block();
		DepartmentDto departmentDto=(DepartmentDto) apiCilent.getMethodName(saveEmployee.getDepartmentid());

		ApirequestDto apirequestDto = new ApirequestDto();
		apirequestDto.setDepartmentDto(departmentDto);
		apirequestDto.setEmpolyeeDto(saveEmployee);
		return new ResponseEntity<>(apirequestDto, HttpStatus.CREATED);

	}

}
