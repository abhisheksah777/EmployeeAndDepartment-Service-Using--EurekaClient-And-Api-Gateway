package com.example.EmployeeService.FeignCilent;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.EmployeeService.DTO.DepartmentDto;

//@FeignClient(url = "http://localhost:8081", value = "DepartMentCilent")
@FeignClient(name="DEPARTMENT-SERVICE")
public interface ApiCilent {
	@GetMapping("/department/{dept_Id}")
	DepartmentDto getMethodName(@PathVariable("dept_Id") Long dept_Id);

}
