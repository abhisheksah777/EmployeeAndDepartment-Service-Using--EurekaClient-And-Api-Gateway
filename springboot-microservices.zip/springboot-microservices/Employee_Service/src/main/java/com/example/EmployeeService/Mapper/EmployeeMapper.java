package com.example.EmployeeService.Mapper;

import com.example.EmployeeService.DTO.EmpolyeeDto;
import com.example.EmployeeService.Entity.Employee;

public class EmployeeMapper {

	public static Employee EmployeeDtoToEmployee(EmpolyeeDto empolyeeDto) {
		return new Employee(empolyeeDto.getEmpId(), empolyeeDto.getFirstName(), empolyeeDto.getLastName(),
				empolyeeDto.getEmail(),empolyeeDto.getDepartmentid());
	}

	public static EmpolyeeDto EmployeeToEmployeeDto(Employee empolyee) {
		return new EmpolyeeDto(empolyee.getEmpId(), empolyee.getFirstName(), empolyee.getLastName(),
				empolyee.getEmail(),empolyee.getDepartmentid());

	}

}
