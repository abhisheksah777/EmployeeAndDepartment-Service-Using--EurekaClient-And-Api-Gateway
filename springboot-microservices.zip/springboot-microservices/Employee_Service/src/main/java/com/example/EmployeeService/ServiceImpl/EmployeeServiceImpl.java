package com.example.EmployeeService.ServiceImpl;

import java.util.List;

import org.apache.catalina.mapper.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.EmployeeService.DTO.EmpolyeeDto;
import com.example.EmployeeService.Entity.Employee;
import com.example.EmployeeService.Mapper.EmployeeMapper;
import com.example.EmployeeService.Repository.EmployeeRepo;
import com.example.EmployeeService.Service.EmployeeService;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Service

public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepo employeeRepo;
	EmployeeMapper employeeMapper;

	@Override
	public EmpolyeeDto saveEmployee(EmpolyeeDto empolyeeDto) {
		Employee saveEmployee = employeeRepo.save(employeeMapper.EmployeeDtoToEmployee(empolyeeDto));
		return employeeMapper.EmployeeToEmployeeDto(saveEmployee);
	}

	@Override
	public EmpolyeeDto getEmployeeById(Long empId) {
		Employee saveEmployee = employeeRepo.findById(empId).get();
		return employeeMapper.EmployeeToEmployeeDto(saveEmployee);
	}

	@Override
	public List<EmpolyeeDto> getEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

}
