package com.example.EmployeeService.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentDto {
	private Long dept_Id;
	private String departmentName;
	private String departmentDesc;
	private String departmentCode;

}
