package com.example.EmployeeService.Service;

import java.util.List;

import com.example.EmployeeService.DTO.EmpolyeeDto;

public interface EmployeeService {
	public EmpolyeeDto saveEmployee(EmpolyeeDto  empolyeeDto);
	public EmpolyeeDto getEmployeeById(Long empId);
	 public List<EmpolyeeDto> getEmployee();

}
